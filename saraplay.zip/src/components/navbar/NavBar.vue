<template>
  <nav class="navbar bg-transparent px-2">
    Logo
  </nav>
</template>

<script>
export default {
  name: 'NavBar'
}
</script>

<style lang="scss">

</style>
