<template>
  <div class="container-fluid">
    <div class="row">
      <vue-plyr>
          <div class="plyr__video-embed">
            <iframe src="https://www.youtube.com/embed/xfcQLQ88DmI?amp;iv_load_policy=3&amp;modestbranding=0&amp;playsinline=0&amp;showinfo=0&amp;rel=0&amp;enablejsapi=0" allowfullscreen allowtransparency allow="autoplay"></iframe>
          </div>
        </vue-plyr>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PlayerComponent'
}
</script>

<style>

</style>
