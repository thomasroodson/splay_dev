export default {
  destaques: [],
  planos: [],
  filmsHome: [
    { id: 1, img: 'https://www.themoviedb.org/t/p/original/yRGDZI2lYTgUM3ifsoFASU5z77v.jpg' },
    { id: 2, img: 'https://www.themoviedb.org/t/p/original/g7Ii9sYAFG96W7cvMQ4zXq39RJ5.jpg' },
    { id: 3, img: 'https://www.themoviedb.org/t/p/original/4xNH5hHPpTJptSWANyAX3OLZoNM.jpg' },
    { id: 4, img: 'https://www.themoviedb.org/t/p/original/2xtqkht2u7SkrZPd6zyMRymE4nt.jpg' },
    { id: 5, img: 'https://www.themoviedb.org/t/p/original/vsX9gj7t56ZlMYKNYccskeW5adT.jpg' },
    { id: 6, img: 'https://www.themoviedb.org/t/p/original/f4SvCKIUrC2cDR7Xo4k1kaGAqQ2.jpg' }
  ],
  cultos: [],
  categorias: []
}
