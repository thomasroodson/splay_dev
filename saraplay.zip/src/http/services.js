import { services as auth } from '@/modules/auth'
import { services as components } from '@/components'

export default {
  auth,
  components
}
