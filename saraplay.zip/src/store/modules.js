import { store as auth } from '../modules/auth'
import { store as components } from '../components'

export default {
  auth,
  components
}
