export default {
  loadMovie: { method: 'get', url: 'conteudos{/id}' }
}
