export default {
  movie: {}
}
