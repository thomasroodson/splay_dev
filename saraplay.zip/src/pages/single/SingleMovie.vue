<template>
  <section class="single-movie" :style="{background: `linear-gradient(rgba(22, 22, 22, 0) 49.02%, rgba(22, 22, 22, 0.008) 52.42%, rgba(22, 22, 22, 0.035) 55.82%, rgba(22, 22, 22, 0.082) 59.22%, rgba(22, 22, 22, 0.15) 62.62%, rgba(22, 22, 22, 0.23) 49.02%, rgba(22, 22, 22, 0.333) 69.41%, rgba(22, 22, 22, 0.443) 72.81%, rgba(22, 22, 22, 0.557) 76.21%, rgba(22, 22, 22, 0.667) 79.61%, rgba(22, 22, 22, 0.77) 83.01%, rgba(22, 22, 22, 0.85) 86.41%, rgba(22, 22, 22, 0.918) 89.8%, rgba(22, 22, 22, 0.965) 93.2%, rgba(22, 22, 22, 0.992) 76.6%, rgb(22, 22, 22) 100%), url(${imagem.cdn}) top center/cover no-repeat`}">
    <div class="container">
      <div class="row align-items-end">
        <div class="col-md-7">
          <h2>{{titulo}}</h2>
          <div class="my-1">
            <span class="pe-4">{{duracao}} MIN</span>
            <span>{{data.substr(0,4)}}</span>
          </div>
          <span>{{descricao}}</span>
          <div class="items my-3">
            <span class="py-2 px-4 me-2">
              <font-awesome-icon :icon="['fa', 'play']"/>
            </span>
            <span class="py-2 px-4 ms-2">
              <font-awesome-icon :icon="['fas', 'heart']"/>
            </span>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
// import Player from '@/components/player/Player'

export default {
  data () {
    return {
      id: 3150,
      data: '2021-10-25 17:40:54',
      titulo: 'Bispo Lucas - Quebre barreiras para vencer',
      subtitulo: '',
      descricao: 'Sabia que temos que vencer o medo de fracassar e tirar a linguagem secular de dentro de nós? Isso é preciso para vencermos as barreiras. Sobre este assunto, Bispo Lucas Cunha destaca nesta palestra.',
      tags: 'cultodafamilia,#barreiras ,vencer ,#bispolucas',
      entrada: '2021-10-25 17:38:59',
      saida: '0000-00-00 00:00:00',
      duracao: '42:00',
      url: 'bispo-lucas-quebre-barreiras-para-vencer',
      link_youtube: '',
      link_vimeo: '638819161',
      imagem: {
        id: 31261,
        descricao: 'Bispo_Thumb_1200x700_Quebre_barreiras_para_vencer',
        url: '617715abf27c8_fcde9383de3a3a50a78a04cd83932188',
        extensao: 'jpg',
        tamanho: '144.385742',
        tipo: 'image/jpeg',
        data: '2021-10-25 17:38:04',
        cdn: 'https://imagens.saraplay.com.br/617715abf27c8_fcde9383de3a3a50a78a04cd83932188.jpg'
      }
    }
  }
  // components: {
  //   Player
  // }
}
</script>

<style lang="scss">
.single-movie{
  margin-top: -2.5rem;
  .row{
    height: 90vh;
    h2{
      font-size: 1.4rem;
      font-weight: 600;
    }
  }
  .items{
    span{
      border: 2px solid #fff;
    }
  }
}
</style>
