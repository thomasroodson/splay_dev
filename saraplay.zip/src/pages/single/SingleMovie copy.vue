<template>
  <section class="single-movie">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 order-2">
          <h3>{{titulo}}</h3>
          <span>Descrição: {{descricao}}</span>
        </div>
        <div class="col-lg-7 order-1 order-lg-2">
          <Player />
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import Player from '@/components/player/Player'

export default {
  data () {
    return {
      id: 3150,
      data: '2021-10-25 17:40:54',
      titulo: 'Bispo Lucas - Quebre barreiras para vencer',
      subtitulo: '',
      descricao: 'Sabia que temos que vencer o medo de fracassar e tirar a linguagem secular de dentro de nós? Isso é preciso para vencermos as barreiras. Sobre este assunto, Bispo Lucas Cunha destaca nesta palestra.',
      tags: 'cultodafamilia,#barreiras ,vencer ,#bispolucas',
      entrada: '2021-10-25 17:38:59',
      saida: '0000-00-00 00:00:00',
      duracao: '42:00',
      url: 'bispo-lucas-quebre-barreiras-para-vencer',
      link_youtube: '',
      link_vimeo: '638819161',
      imagem: {
        id: 31261,
        descricao: 'Bispo_Thumb_1200x700_Quebre_barreiras_para_vencer',
        url: '617715abf27c8_fcde9383de3a3a50a78a04cd83932188',
        extensao: 'jpg',
        tamanho: '144.385742',
        tipo: 'image/jpeg',
        data: '2021-10-25 17:38:04',
        cdn: 'https://imagens.saraplay.com.br/617715abf27c8_fcde9383de3a3a50a78a04cd83932188.jpg'
      }
    }
  },
  components: {
    Player
  }
}
</script>

<style>

</style>
