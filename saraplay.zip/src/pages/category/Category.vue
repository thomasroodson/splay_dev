<template>
  <div class="home">
  <!--Banner Topo-->
  <section class="container mt-5 pt-5">
    <h3>Celebrações</h3>
    <div class="row">
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
      <div class="col-md-3 p-2">
        <img class="img-fluid" src="https://www.themoviedb.org/t/p/original/zATdeXZdwnCpWuWy9RaHAQMJPKV.jpg">
      </div>
    </div>
  </section>
  </div>
</template>

<script>

export default {
  name: 'CategoryPage',
  data () {
    return {
      data: []
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
