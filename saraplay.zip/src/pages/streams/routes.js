export default [
  {
    path: '/ao-vivo',
    name: 'genesistv',
    component: () => import(/* webpackChunkName: "genesistv" */ './GenesisTV')
  }
]
