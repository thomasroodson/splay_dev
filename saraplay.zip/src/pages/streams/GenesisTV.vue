<template>
  <section class="genesis-tv">
    <div class="container-fluid no-gutters">
      <div class="row">
        <div class="col-12">
          <div class="video-container">
            <iframe src="https://www.youtube.com/embed/ibevatNsdpg"></iframe>
          </div>
        </div>
      </div>
    </div>

  </section>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>

</style>
