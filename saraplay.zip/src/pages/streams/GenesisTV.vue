<template>
  <section id="genesis-tv">
    <div class="container-fluid mt-5">
      <div class="video-container">
        <iframe src="https://www.youtube.com/embed/ibevatNsdpg"></iframe>
      </div>
    </div>
  </section>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
  #genesis-tv{
    height: calc(100vh - 300px);
  }
</style>
