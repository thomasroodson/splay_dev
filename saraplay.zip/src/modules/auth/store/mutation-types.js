export const SET_USER = 'AUTH/SET_USER'
export const SET_TOKEN = 'AUTH/SET_TOKEN'
