export default {
  user: {},
  token: ''
}
