export default {
  login: { method: 'post', url: 'auth/login' },
  register: { method: 'post', url: 'auth/register' }
}
